﻿namespace AssetPackage
{
    /// <summary>
    /// Interface for bridge.
    /// </summary>
    public interface IBridge
    {
        #region Other

        //

        #endregion Other
    }
}
