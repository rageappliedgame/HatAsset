﻿namespace AssetPackage
{
    using System;

    /// <summary>
    /// Interface for settings.
    /// </summary>
    public interface ISettings
    {
        #region Other

        //

        #endregion Other
    }
}